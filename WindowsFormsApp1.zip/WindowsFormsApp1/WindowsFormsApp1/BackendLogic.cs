﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;
using System.Diagnostics;

namespace NRSSSNamespace
{

    public static class BackendLogic
    {

        public static string studentName;
        public static int secondsTimer;
        public static int inputOption;

        public static Image[] arrayOfImages = new Image[3]; 


        public static void SetupApp()
        {
            studentName = "error";
            secondsTimer = 0;
            inputOption = -1;

            arrayOfImages[0] = Image.FromFile("Instruments.jpg");
            arrayOfImages[1] = Image.FromFile("Models.jpg");
            arrayOfImages[2] = Image.FromFile("Vehicles.jpg");

            //Debug.WriteLine("____----____" + Directory.GetCurrentDirectory());

        
        }

        



    }


}
